from __future__ import annotations

import os
from typing import Any, Dict

import httpx


class BridgeClient:
    """Lightweight HTTP client used inside Blender to talk to the MCP server."""

    def __init__(self, base_url: str | None = None) -> None:
        base = base_url or os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000")
        self.base_url = base.rstrip("/")
        self._timeout = 10.0

    def ping(self) -> Dict[str, Any]:
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(f"{self.base_url}/health")
            resp.raise_for_status()
            return resp.json()

    def send_snapshot(self, snapshot: Dict[str, Any]) -> Dict[str, Any]:
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(f"{self.base_url}/blender/scene_snapshot", json=snapshot)
            resp.raise_for_status()
            return resp.json()

    def send_dummy_snapshot(self) -> Dict[str, Any]:
        dummy = {
            "session_id": "demo_session",
            "objects": [{"name": "Cube", "type": "MESH", "location": [0, 0, 0]}],
            "metadata": {"source": "blender_addon_stub"},
        }
        return self.send_snapshot(dummy)

    def run_tool(self, tool_name: str, arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
        arguments = arguments or {}
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(f"{self.base_url}/tools/{tool_name}/invoke", json={"arguments": arguments})
            resp.raise_for_status()
            return resp.json()

    def plan_task(self, instruction: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self.base_url}/tools/plan_task/invoke", json={"arguments": {"instruction": instruction}}
            )
            resp.raise_for_status()
            return resp.json()

    def run_task(self, instruction: str) -> Dict[str, Any]:
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self.base_url}/tools/run_task/invoke", json={"arguments": {"instruction": instruction}}
            )
            resp.raise_for_status()
            return resp.json()
